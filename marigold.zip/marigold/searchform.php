<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
	<input type="text" placeholder="<?php _e('Search and hit enter...', 'marigold'); ?>" name="s" id="s" />
</form>